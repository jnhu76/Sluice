import importlib.util,json
from pathlib import Path
import subprocess,sys
root=Path('/home/jnhu/final-closeout-20261012');repo=root/'worktrees/f3'
spec=importlib.util.spec_from_file_location('f4',repo/'scripts/verify_f4_retirement.py');f4=importlib.util.module_from_spec(spec);spec.loader.exec_module(f4)
ex=f4.Experiment(root/'evidence/f3-matrix-01');sha=f4.git(ex,repo,'rev-parse','HEAD');results=[]
targets=['app_hash_consumption_test','app_grep_consumption_test','app_copy_consumption_test','app_copy_pipeline_oracle_test','app_copy_dir_fsync_test','app_tail_consumption_test','app_tail_lifecycle_oracle_test','app_tail_cli_oracle_test','request_scope_test','public_request_test','public_request_release_violation_test','backend_conformance_e1_threadpool_test','shutdown_lifecycle_test','direct_w01_consumer_probe','blocking_file_read_test','semantic_short_io_reference_test','file_close_semantics_test']
for profile in ('no-liburing','real-liburing'):
 for mode in ('debug','release'):
  key=mode+'-'+profile;tree=root/'worktrees'/('f3-'+key)
  ex.checked(['git','-C',repo,'worktree','add','--detach',tree,sha]);build=ex.output/'build'/key
  ex.checked(['xmake','f','-y','-m',mode,'-o',build,f'--liburing={"y" if profile=="real-liburing" else "n"}'],cwd=tree)
  binary_dir=build/'linux/x86_64'/mode;row=dict(profile=profile,mode=mode,source_sha=sha,targets={},cli={})
  try:
   for app in ('hash','grep','copy','tail'):ex.checked(['xmake','-y','-j','4','sluice-'+app],cwd=tree,timeout=600)
   extra=['request_scope_uring_test','public_request_uring_test','public_request_release_violation_uring_test','backend_conformance_e1_uring_test','shutdown_lifecycle_uring_test'] if profile=='real-liburing' else []
   for t in targets+extra:
    ex.checked(['xmake','-y','-j','4',t],cwd=tree,timeout=600)
    c,_,_=ex.run([binary_dir/t],cwd=tree,timeout=180);row['targets'][t]=dict(command=c['id'],status=f4.status(c))
   scripts=[['tests/app_direct_cli_oracle.py','hash',binary_dir/'sluice-hash'],['tests/app_direct_cli_oracle.py','grep',binary_dir/'sluice-grep'],['tests/hash_cli_oracle.py',binary_dir/'sluice-hash','--early-bounds'],['tests/grep_cli_oracle.py',binary_dir/'sluice-grep',ex.output/(key+'-grep-traces')],['docs/evidence/f3-copy-request-scope/cli_smoke.py',binary_dir/'sluice-copy'],['tests/f3_preflight_cli_oracle.py','tail',binary_dir/'sluice-tail',ex.output/(key+'-tail-preflight')],['tests/f3_preflight_cli_oracle.py','copy',binary_dir/'sluice-copy',ex.output/(key+'-copy-preflight')]]
   for args in scripts:
    c,_,_=ex.run(['python3',*args],cwd=tree,timeout=180);row['cli'][args[0]+str(args[1])]=dict(command=c['id'],status=f4.status(c))
   row['status']='PASS' if all(x['status']=='PASS' for x in [*row['targets'].values(),*row['cli'].values()]) else 'FAIL'
  except Exception as e:row.update(status='BLOCKED',reason=str(e))
  results.append(row);(ex.output/'evidence.json').write_text(json.dumps(dict(tested_sha=sha,results=results,commands=ex.commands),indent=2)+'\n');print(key,row['status'],row.get('reason',''),flush=True)
sys.exit(any(r['status']!='PASS' for r in results))
