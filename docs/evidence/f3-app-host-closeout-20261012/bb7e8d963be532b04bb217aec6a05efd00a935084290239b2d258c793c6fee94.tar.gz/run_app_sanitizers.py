import importlib.util,json,sys
from pathlib import Path
root=Path('/home/jnhu/final-closeout-20261012');repo=root/'worktrees/f3'
spec=importlib.util.spec_from_file_location('f4',repo/'scripts/verify_f4_retirement.py');f4=importlib.util.module_from_spec(spec);spec.loader.exec_module(f4)
ex=f4.Experiment(root/'evidence/f3-sanitizers-01');sha=f4.git(ex,repo,'rev-parse','HEAD');results=[]
for mode in ('asanubsan','tsan'):
 for profile in ('no-liburing','real-liburing'):
  key=mode+'-'+profile;tree=root/'worktrees'/('f3-'+key)
  ex.checked(['git','-C',repo,'worktree','add','--detach',tree,sha]);build=ex.output/'build'/key
  ex.checked(['xmake','f','-y','--toolchain=clang','-m',mode,'-o',build,f'--liburing={"y" if profile=="real-liburing" else "n"}'],cwd=tree)
  bin=build/'linux/x86_64'/mode;row=dict(profile=profile,mode=mode,source_sha=sha,targets={})
  targets=['app_tail_consumption_test','app_tail_lifecycle_oracle_test','app_tail_cli_oracle_test','app_copy_consumption_test','app_copy_pipeline_oracle_test','app_copy_dir_fsync_test'] if mode=='asanubsan' else ['app_tail_lifecycle_oracle_test','app_tail_cli_oracle_test','app_copy_pipeline_oracle_test']
  try:
   for t in targets:
    ex.checked(['xmake','-y','-j','4',t],cwd=tree,timeout=600)
    filters=['depth4_full_read_window','exception_cleanup_waits_for_held_borrow','canceled_result_settles_held_readahead','drained_results_never_override_primary'] if mode=='tsan' and t=='app_copy_pipeline_oracle_test' else ['']
    for filt in filters:
     env=f4.clean_env()
     if filt:env['SLUICE_ORACLE_FILTER']=filt
     c,_,_=ex.run([bin/t],cwd=tree,env=env,timeout=180);row['targets'][t+('/'+filt if filt else '')]=dict(command=c['id'],filter=filt,status=f4.status(c))
   row['status']='PASS' if all(r['status']=='PASS' for r in row['targets'].values()) else 'FAIL'
  except Exception as e:row.update(status='BLOCKED',reason=str(e))
  results.append(row);(ex.output/'evidence.json').write_text(json.dumps(dict(tested_sha=sha,results=results,commands=ex.commands),indent=2)+'\n');print(key,row['status'],row.get('reason',''),flush=True)
sys.exit(any(r['status']!='PASS' for r in results))
