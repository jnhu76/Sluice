#!/bin/bash
set -euo pipefail
export PATH=/home/jnhu/.local/bin:/usr/bin:/bin
export CCACHE_DISABLE=1
root=/home/jnhu/Source/Sluice-f3-498-pr-b-tsan-shared-n
ev=/home/jnhu/f3-498-execution/pr-b-tsan-shared-n
cd "$root"
exec >"$ev/driver.log" 2>&1
git rev-parse HEAD >"$ev/sha.txt"
xmake f -y -o build-final --ccache=n --toolchain=clang --cxx=/usr/bin/clang++ --cc=/usr/bin/clang -m tsan --liburing=n "--ldflags=--target=x86_64-redhat-linux-gnu -shared-libsan -Wl,-rpath,/usr/lib/clang/22/lib/x86_64-redhat-linux-gnu" >"$ev/config.log" 2>&1
xmake build -v -j2 request_scope_test >"$ev/build.log" 2>&1
timeout 240 xmake run request_scope_test >"$ev/run.log" 2>&1
nm build-final/linux/x86_64/tsan/request_scope_test >"$ev/symbols.txt"
rg "__tsan_init|__tsan_" "$ev/symbols.txt" >"$ev/instrumentation.txt"
ldd build-final/linux/x86_64/tsan/request_scope_test >"$ev/ldd.txt"
rg "libclang_rt.tsan.so => /usr/lib/clang/22/lib/x86_64-redhat-linux-gnu/libclang_rt.tsan.so" "$ev/ldd.txt"
cp .xmake/linux/x86_64/xmake.conf "$ev/xmake.conf"
cp .xmake/linux/x86_64/cache/toolchain "$ev/toolchain-cache.txt"
echo PASS >"$ev/status"
