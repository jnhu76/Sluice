#!/usr/bin/env bash
set -u
mode=$1
uring=$2
kind=${3:-base}
root=/home/jnhu/Source/Sluice-f3-498-pr-b-${mode}-${uring}
evidence=/home/jnhu/f3-498-execution/pr-b-matrix/${mode}-${uring}
mkdir -p "$evidence"
cd "$root" || exit 2
exec >"$evidence/driver.log" 2>&1
printf 'START=%s\n' "$(date -Is)"
git rev-parse HEAD > "$evidence/sha.txt"
uname -a > "$evidence/environment.txt"
if [[ "$kind" == sanitizer ]]; then
  xmake f -y --ccache=n --toolchain=clang -m "$mode" --liburing="$uring" --ldflags=--target=x86_64-redhat-linux-gnu > "$evidence/config.log" 2>&1 || { echo CONFIG_FAILED > "$evidence/status"; exit 1; }
  targets=(file_read_test file_write_test file_sync_data_test file_sync_all_test explicit_file_ref_test file_access_precedence_test request_scope_test public_request_test threadpool_core_cutover_test progress_source_ownership_test threadpool_progress_race_test threadpool_external_loop_test shutdown_lifecycle_test)
else
  xmake f -y --ccache=n -m "$mode" --liburing="$uring" > "$evidence/config.log" 2>&1 || { echo CONFIG_FAILED > "$evidence/status"; exit 1; }
  targets=(file_read_test file_write_test file_sync_data_test file_sync_all_test explicit_file_ref_test file_access_precedence_test async_sync_admission_test progress_source_ownership_test file_resource_test file_open_contract_test blocking_file_read_test blocking_file_write_test blocking_file_sync_data_test blocking_file_sync_all_test blocking_file_state_test blocking_file_sequential_test semantic_errno_mapping_test semantic_open_test semantic_range_test semantic_short_io_reference_test semantic_effect_outcome_test semantic_durability_reference_test semantic_reference_case_test semantic_validation_precedence_test request_core_protocol_test request_core_publication_test public_request_test public_request_release_violation_test request_scope_test threadpool_core_cutover_test backend_conformance_e1_threadpool_test shutdown_lifecycle_test threadpool_progress_race_test threadpool_external_loop_test runtime_waiter_observer_test stackful_host_test app_copy_pipeline_oracle_test app_tail_lifecycle_oracle_test app_hash_consumption_test app_grep_consumption_test)
  if [[ "$uring" == y ]]; then
    targets+=(uring_backend_smoke_test semantic_backend_conformance_test uring_public_consumer_probe public_request_uring_test request_scope_uring_test uring_core_cutover_test backend_conformance_e1_uring_test shutdown_lifecycle_uring_test progress_source_ownership_uring_test uring_external_loop_test uring_progress_race_test uring_registration_lifecycle_test)
  fi
fi
printf '%s\n' "${targets[@]}" > "$evidence/targets.txt"
: > "$evidence/results.tsv"
failed=0
for target in "${targets[@]}"; do
  printf 'BUILD=%s\n' "$target"
  if xmake build -v -j 2 "$target" > "$evidence/$target.build.log" 2>&1; then
    printf 'RUN=%s\n' "$target"
    if timeout 240 xmake run "$target" > "$evidence/$target.run.log" 2>&1; then
      printf '%s\tPASS\n' "$target" >> "$evidence/results.tsv"
    else
      code=$?
      printf '%s\tRUN_FAIL_%s\n' "$target" "$code" >> "$evidence/results.tsv"
      failed=1
    fi
  else
    printf '%s\tBUILD_FAIL\n' "$target" >> "$evidence/results.tsv"
    failed=1
  fi
done
if [[ "$kind" == base ]]; then
  # Capture each migrated consumer compiler closure from this exact source tree.
  cxx=/usr/bin/g++
  define=()
  [[ "$uring" == y ]] && define=(-DSLUICE_HAS_LIBURING)
  for source in file_read_test file_write_test file_sync_data_test file_sync_all_test explicit_file_ref_test file_access_precedence_test async_sync_admission_test progress_source_ownership_test; do
    "$cxx" -std=c++20 "${define[@]}" -Iinclude -MM "tests/$source.cpp" > "$evidence/$source.dependencies.txt" 2>&1 || failed=1
    nm -C "build/linux/x86_64/$mode/$source" > "$evidence/$source.symbols.txt" 2>&1 || failed=1
  done
  if [[ "$uring" == y ]]; then
    "$cxx" -std=c++20 "${define[@]}" -Iinclude -MM tests/uring_backend_smoke_test.cpp > "$evidence/uring_backend_smoke_test.dependencies.txt" 2>&1 || failed=1
    nm -C "build/linux/x86_64/$mode/uring_backend_smoke_test" > "$evidence/uring_backend_smoke_test.symbols.txt" 2>&1 || failed=1
  fi
  xmake install -o "$evidence/install" sluice_core > "$evidence/install-core.log" 2>&1 || failed=1
  xmake install -o "$evidence/install" sluice_async > "$evidence/install-async.log" 2>&1 || failed=1
  find "$evidence/install/include" -type f | sort > "$evidence/installed-headers.txt"
  ar t "build/linux/x86_64/$mode/libsluice_async.a" > "$evidence/async-members.txt"
  ar t "build/linux/x86_64/$mode/libsluice_core.a" > "$evidence/core-members.txt"
else
  for target in file_read_test request_scope_test threadpool_core_cutover_test; do
    nm "build/linux/x86_64/$mode/$target" | rg '__asan_init|__ubsan_handle|__tsan_init' > "$evidence/$target.instrumentation-symbols.txt" || failed=1
  done
fi
printf 'END=%s\n' "$(date -Is)"
[[ "$failed" == 0 ]] && echo PASS > "$evidence/status" || echo FAIL > "$evidence/status"
exit "$failed"
