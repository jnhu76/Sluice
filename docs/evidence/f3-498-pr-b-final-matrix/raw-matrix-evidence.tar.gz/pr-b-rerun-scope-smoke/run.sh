#!/bin/bash
set -u
export PATH=/home/jnhu/.local/bin:/usr/bin:/bin
export CCACHE_DISABLE=1
mode=$1; p=$2; output=/home/jnhu/f3-498-execution/pr-b-rerun-scope-smoke/$mode-$p
mkdir -p "$output"
cd /home/jnhu/Source/Sluice-f3-498-pr-b-$mode-$p || exit 2
exec >"$output/driver.log" 2>&1
git rev-parse HEAD >"$output/sha.txt"
if [[ "$mode" == asanubsan || "$mode" == tsan ]]; then
 xmake f -y --ccache=n --toolchain=clang --cc=/usr/bin/clang --cxx=/usr/bin/clang++ -m "$mode" --liburing="$p" --ldflags=--target=x86_64-redhat-linux-gnu >"$output/config.log" 2>&1 || exit 2
else
 xmake f -y --ccache=n --cc=/usr/bin/gcc --cxx=/usr/bin/g++ -m "$mode" --liburing="$p" >"$output/config.log" 2>&1 || exit 2
fi
targets=(request_scope_test)
[[ "$p" == y ]] && targets+=(uring_backend_smoke_test)
: >"$output/results.tsv"
for target in "${targets[@]}"; do
 if xmake build -v -j2 "$target" >"$output/$target.build.log" 2>&1; then
  if timeout 240 xmake run "$target" >"$output/$target.run.log" 2>&1; then
   printf "%s\tPASS\n" "$target" >>"$output/results.tsv"
  else
   printf "%s\tRUN_FAIL_%s\n" "$target" "$?" >>"$output/results.tsv"
  fi
 elif [[ "$mode" == tsan && "$target" == request_scope_test ]] && rg "multiple definition.*operator (new|delete)" "$output/$target.build.log" >/dev/null; then
  printf "%s\tLINK_UNAVAILABLE_STRONG_ALLOCATION_OVERRIDES\n" "$target" >>"$output/results.tsv"
 else
  printf "%s\tBUILD_FAIL\n" "$target" >>"$output/results.tsv"
 fi
done
cp .xmake/linux/x86_64/xmake.conf "$output/xmake.conf"
cp .xmake/linux/x86_64/cache/toolchain "$output/toolchain-cache.txt"
echo DONE >"$output/status"
