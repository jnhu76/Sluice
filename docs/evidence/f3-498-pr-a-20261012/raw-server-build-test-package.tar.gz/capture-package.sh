#!/usr/bin/env bash
set -e
export CCACHE_DISABLE=1
mode=$1
uring=$2
root=/home/jnhu/Source/Sluice-f3-498-pr-a-${mode}-${uring}
evidence=/home/jnhu/f3-498-execution/pr-a-final-matrix/${mode}-${uring}
cd "$root"
xmake lua /home/jnhu/f3-498-execution/pr-a-final-matrix/resolve.lua "$evidence/resolved.json" > "$evidence/resolved-command.log" 2>&1
flags=()
[[ "$uring" == y ]] && flags=(-DSLUICE_HAS_LIBURING)
links=()
[[ "$uring" == y ]] && links=(-luring)
source=/home/jnhu/f3-498-execution/pr-a-final-matrix/installed-consumer.cpp
prefix="$evidence/install"
printf '%q ' /usr/bin/g++ -std=c++20 -g "${flags[@]}" -I"$prefix/include" "$source" "$prefix/lib/libsluice_async.a" "$prefix/lib/libsluice_core.a" -pthread "${links[@]}" -Wl,-Map="$evidence/installed-consumer.map" -o "$evidence/installed-consumer" > "$evidence/installed-consumer.command.txt"
/usr/bin/g++ -std=c++20 -g "${flags[@]}" -I"$prefix/include" "$source" "$prefix/lib/libsluice_async.a" "$prefix/lib/libsluice_core.a" -pthread "${links[@]}" -Wl,-Map="$evidence/installed-consumer.map" -o "$evidence/installed-consumer" > "$evidence/installed-consumer.compile.log" 2>&1
"$evidence/installed-consumer" > "$evidence/installed-consumer.run.log" 2>&1
/usr/bin/g++ -std=c++20 "${flags[@]}" -I"$prefix/include" -MM "$source" > "$evidence/installed-consumer.dependencies.txt"
nm -C "$evidence/installed-consumer" > "$evidence/installed-consumer.symbols.txt"
sha256sum "$prefix/lib/libsluice_async.a" "$prefix/lib/libsluice_core.a" > "$evidence/installed-archives.sha256"
(cd "$prefix/include" && find . -type f -print0 | sort -z | xargs -0 sha256sum) > "$evidence/installed-headers.sha256"
echo PASS > "$evidence/installed-consumer.status"
