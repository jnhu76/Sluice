#!/usr/bin/env bash
set -u
export CCACHE_DISABLE=1
root=/home/jnhu/Source/Sluice-f3-498-pr-a-tsan-shared-n
evidence=/home/jnhu/f3-498-execution/pr-a-final-matrix/tsan-shared-n
mkdir -p "$evidence"
cd "$root" || exit
git rev-parse HEAD > "$evidence/sha.txt"
xmake f -y -o build-final --ccache=n --toolchain=clang --cxx=/usr/bin/clang++ --cc=/usr/bin/clang -m tsan --liburing=n '--ldflags=--target=x86_64-redhat-linux-gnu -shared-libsan -Wl,-rpath,/usr/lib/clang/22/lib/x86_64-redhat-linux-gnu' > "$evidence/config.log" 2>&1 || exit
if xmake build -v -j 2 request_scope_test > "$evidence/request_scope_test.build.log" 2>&1 && timeout 240 xmake run request_scope_test > "$evidence/request_scope_test.run.log" 2>&1; then
 echo PASS > "$evidence/status"
else
 echo FAIL > "$evidence/status"
fi
nm build-final/linux/x86_64/tsan/request_scope_test | rg '__tsan_init|__tsan_' > "$evidence/instrumentation-symbols.txt"
ldd build-final/linux/x86_64/tsan/request_scope_test > "$evidence/runtime-libraries.txt"
