#!/usr/bin/env bash
set -u
export CCACHE_DISABLE=1
cd /home/jnhu/Source/Sluice-f3-498-pr-a-controls-y || exit
evidence=/home/jnhu/f3-498-execution/pr-a-final-matrix/controls-y
mkdir -p "$evidence"
git rev-parse HEAD > "$evidence/sha.txt"
xmake f -y -o build-final --cxx=/usr/bin/g++ --cc=/usr/bin/gcc -m debug --liburing=y --ccache=n > "$evidence/config.log" 2>&1 || exit
for target in request_scope_mut_commit_drops_request request_scope_mut_timeout_releases_slot request_scope_mut_destructor_skips_settle uring_cutover_mut_zero_op_dispatch; do
 if xmake build -v -j 2 "$target" > "$evidence/$target.build.log" 2>&1; then
  timeout 120 xmake run "$target" > "$evidence/$target.run.log" 2>&1
  code=$?
  printf '%s\t%s\n' "$target" "$code" >> "$evidence/results.tsv"
 else
  printf '%s\tBUILD_FAIL\n' "$target" >> "$evidence/results.tsv"
 fi
done
echo COMPLETE > "$evidence/status"
