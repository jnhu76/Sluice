function main(output)
    import("core.project.config")
    config.load()
    import("core.project.project")
    import("core.base.json")
    local out = {}
    for _, name in ipairs({"sluice_core", "sluice_async", "file_read_test", "file_write_test", "file_sync_data_test", "file_sync_all_test", "explicit_file_ref_test", "file_access_precedence_test", "async_sync_admission_test", "progress_source_ownership_test"}) do
        local t = project.target(name)
        out[name] = {sources = t:sourcefiles(), objects = t:objectfiles(), target = t:targetfile(), dependencies = t:get("deps")}
    end
    if config.get("liburing") then
        local t = project.target("uring_backend_smoke_test")
        out.uring_backend_smoke_test = {sources = t:sourcefiles(), objects = t:objectfiles(), target = t:targetfile(), dependencies = t:get("deps")}
    end
    io.writefile(output, json.encode(out))
end
