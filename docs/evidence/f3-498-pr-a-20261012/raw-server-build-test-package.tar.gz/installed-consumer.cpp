#include <sluice/async/request_scope.hpp>
#include <sluice/async/stackful_io_host.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <sluice/file_resource.hpp>

#include <chrono>
#include <memory>
#include <type_traits>

static_assert(std::is_nothrow_move_constructible_v<sluice::async::Request<std::size_t>>);

int main() {
    using namespace sluice::async;
    auto opened = sluice::File::open("/dev/null");
    if (!opened.has_value())
        return 1;
    sluice::File file = std::move(opened).value();
    AsyncIoContext ctx(std::make_unique<ThreadPoolBackend>());
    {
        RequestScope scope(ctx, 1, ScopeCleanupPolicy::drain);
        auto admitted = scope.submit_read(ReadOp{file, nullptr, 0, 0});
        if (!admitted.has_value())
            return 2;
        auto waited = scope.wait_for(admitted.value(), std::chrono::seconds(1));
        if (!waited.has_value() || waited.value() != ScopeWaitStatus::ready)
            return 3;
        auto terminal = scope.take(admitted.value());
        if (terminal.readiness != RequestReadiness::ready || !terminal.result.has_value() ||
            terminal.result.value() != 0 || !scope.finish().has_value())
            return 4;
    }
    auto host = StackfulIoHost::create(ctx, {});
    if (!host.has_value())
        return 5;
    return file.close().has_value() ? 0 : 6;
}
