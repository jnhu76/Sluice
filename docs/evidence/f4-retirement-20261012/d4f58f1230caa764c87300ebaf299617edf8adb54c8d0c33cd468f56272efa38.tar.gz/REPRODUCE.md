# F4 archived evidence

The accepted installed experiment is run-02. run-01 is calibration and its
original overall FAIL is retained. Sanitizers-01 preserves the original W02
consumer ASan UAF and TSan race; sanitizers-02 records corrected consumer
execution from #511/#512 against unchanged combined library production.

The exact executed runner/source snapshot is executed-verifier-source.tar;
integrity-verifier-source.tar contains the stronger final rejection checks.
Every command, exit code, stdout/stderr SHA256 and per-interface result is in
run-02/evidence.json. Reproduction commands are in run-02/REPRODUCE.md.
Unpack source snapshots into a new directory; create five new worktrees at the
recorded SHAs, reconstruct integration from the recorded deletion commits,
and choose a nonexistent output. Do not reuse or clean the original checkout.
Integrity-only mode does not repeat compilation or execution.

FILE_INDEX.json records every raw evidence and installed file digest. Original
installation prefixes stay on the remote host; the archive includes the final
installed headers and static libraries. Archived integrity checks read raw
logs even if those original prefixes are absent. Owner packets are outside
this archive to avoid a self-referential evidence digest. Human approval is
PENDING, W04 support is NO, release readiness is NO.
