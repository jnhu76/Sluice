# F4 technical evidence

Status: PASS

- F4-01 `sluice/blocking_io_pool.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: general task pool; no v1 equivalent
- F4-02 `sluice/detail/blocking_io_pool_impl.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: implementation fragment requires public parent; no v1 equivalent
- F4-03 `sluice/buffer.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 stream buffering product
- F4-04 `sluice/buffered_readable.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 stream peek/consume equivalent
- F4-05 `sluice/copy.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: application may loop canonical operations; no stream copy adapter
- F4-06 `sluice/copy_strategy.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 copy strategy product
- F4-07 `sluice/fault.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: test doubles unadmitted; no installed replacement
- F4-08 `sluice/file.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: file_resource.hpp + blocking/file.hpp partially replace scalar resource I/O; vectored/stream excluded
- F4-09 `sluice/io_context.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: canonical File open plus AsyncIoContext request submission; no stream factory equivalent
- F4-10 `sluice/iovec.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: vectored product excluded; no v1 equivalent
- F4-11 `sluice/limit.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 copy limit product
- F4-12 `sluice/memory_io_context.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: test double excluded; no installed equivalent
- F4-13 `sluice/observed.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 stream observation adapter
- F4-14 `sluice/reader.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: canonical scalar reads only; generic stream abstraction excluded
- F4-15 `sluice/sync.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: canonical blocking/request file sync partially replaces file durability; generic writer interface excluded
- F4-16 `sluice/wal.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: no v1 WAL codec or LSN product
- F4-17 `sluice/writer.hpp`: TECHNICALLY_SAFE_FOR_REQUIRED_V1_SCOPE; external use UNKNOWN; human owner PENDING; migration: canonical scalar writes only; generic stream abstraction excluded

Full per-interface facts, commands, exit codes and raw log hashes: evidence.json. W-04 support: NO.
