#include <sluice/async/detail/request_arena.hpp>
int main() {}
