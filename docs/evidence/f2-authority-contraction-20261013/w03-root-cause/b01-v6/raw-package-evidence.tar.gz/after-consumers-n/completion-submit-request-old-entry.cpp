#include <sluice/async/async_io_context.hpp>
#include <sluice/async/completion.hpp>
#include <sluice/async/request_handle.hpp>
using OldRequest = sluice::Result<sluice::async::RequestHandle> (sluice::async::AsyncIoContext::*)(sluice::async::ReadOp, sluice::async::Completion<std::size_t>&);
int main() { OldRequest p = &sluice::async::AsyncIoContext::submit_read_request; return p == nullptr; }
