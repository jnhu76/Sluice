#include <sluice/async/op_helpers.hpp>
using OldReadAll = sluice::Result<std::size_t> (*)(sluice::async::AsyncIoContext&, const sluice::async::NativeFileRef&, std::span<std::byte>, std::uint64_t);
int main() { OldReadAll p = &sluice::async::read_all; return p == nullptr; }
