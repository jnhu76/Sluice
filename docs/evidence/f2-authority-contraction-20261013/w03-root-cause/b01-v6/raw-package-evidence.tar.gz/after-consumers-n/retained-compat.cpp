#include <sluice/async/async_io_context.hpp>
#include <sluice/async/fiber.hpp>
#include <sluice/async/future.hpp>
#include <sluice/async/request.hpp>
#include <sluice/async/scheduler.hpp>
#include <sluice/async/stackful_io_host.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <sluice/file_resource.hpp>
#include <array>
int main() {
    using namespace sluice::async;
    Future<void> future;
    future.complete_with(sluice::Result<void>{});
    if (!future.await()) return 1;
    AsyncIoContext io(std::make_unique<ThreadPoolBackend>());
    {
        Scheduler scheduler(io);
        std::array<std::byte, 65536> stack{};
        Fiber fiber([](Fiber&) {});
        if (!scheduler.init_fiber(fiber, stack.data(), stack.size())) return 2;
        scheduler.spawn(fiber);
        scheduler.run(1);
        if (fiber.state() != FiberState::done) return 3;
    }
    auto host = StackfulIoHost::create(io, {});
    if (!host) return 4;
    RequestId id;
    return id.valid() ? 5 : 0;
}
