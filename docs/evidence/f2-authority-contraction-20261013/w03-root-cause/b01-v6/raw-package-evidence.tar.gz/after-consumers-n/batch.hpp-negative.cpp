#include <sluice/async/batch.hpp>
int main() {}
