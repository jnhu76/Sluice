#include <sluice/async/batch.hpp>
using OldBatch = sluice::Result<std::size_t> (sluice::async::Batch::*)(sluice::async::AsyncIoContext&);
int main() { OldBatch p = &sluice::async::Batch::await_one; return p == nullptr; }
