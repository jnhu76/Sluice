#include <sluice/async/detail/request_slot.hpp>
int main() {}
