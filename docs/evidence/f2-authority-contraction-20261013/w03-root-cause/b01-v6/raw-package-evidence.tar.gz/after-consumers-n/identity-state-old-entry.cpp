#include <sluice/async/async_io_context.hpp>
#include <sluice/async/request_handle.hpp>
using OldState = sluice::Result<sluice::async::RequestHandleState> (sluice::async::AsyncIoContext::*)(const sluice::async::RequestHandle&) const;
int main() { OldState p = &sluice::async::AsyncIoContext::request_state; return p == nullptr; }
