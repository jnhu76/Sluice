#include <sluice/async/async_io_context.hpp>
#include <sluice/async/completion.hpp>
using OldSubmit = sluice::Result<void> (sluice::async::AsyncIoContext::*)(sluice::async::ReadOp, sluice::async::Completion<std::size_t>&);
int main() { OldSubmit p = &sluice::async::AsyncIoContext::submit_read; return p == nullptr; }
