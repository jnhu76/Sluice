import pathlib, subprocess, json, re, hashlib
base=pathlib.Path('/home/jnhu/f3-498-pr-b-prep/before')
ev=base/'evidence'
def run(args, output, cwd=None):
    p=subprocess.run(args,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ev/output).write_text(p.stdout)
    if p.returncode: raise RuntimeError((args,p.returncode,p.stdout[-2000:]))
    return p.stdout
summary={}
for profile in ('n','y'):
    root=base/'profiles'/profile; prefix=base/('installed-'+profile)
    run(['/home/jnhu/.local/bin/xmake','lua','-P',str(root),str(base/'inventory.lua'),str(ev/('resolved-'+profile+'.json'))],'introspection-'+profile+'.log',root)
    headers=sorted(str(p.relative_to(prefix/'include')) for p in (prefix/'include').rglob('*.hpp'))
    (ev/('installed-headers-'+profile+'.txt')).write_text('\n'.join(headers)+'\n')
    objects=sorted(str(p.relative_to(root)) for p in (root/'build/.objs').rglob('*.o'))
    (ev/('objects-'+profile+'.txt')).write_text('\n'.join(objects)+'\n')
    for lib in ('core','async'):
        archive=prefix/'lib'/('libsluice_'+lib+'.a')
        run(['ar','t',str(archive)],'archive-'+lib+'-'+profile+'.txt')
        run(['nm','-C','--defined-only',str(archive)],'defined-'+lib+'-'+profile+'.txt')
        run(['nm','-C','--undefined-only',str(archive)],'undefined-'+lib+'-'+profile+'.txt')
    closures={}
    for name,hdr in [('request','request.hpp'),('context','async_io_context.hpp'),('host','stackful_io_host.hpp'),('task-result','task_result.hpp')]:
        source=base/(name+'.cpp'); source.write_text('#include <sluice/async/'+hdr+'>\nint main() {}\n')
        args=['g++','-std=c++20','-I'+str(prefix/'include')]
        if profile=='y': args+=['-DSLUICE_HAS_LIBURING']
        out=run(args+['-MM',str(source)],'dependencies-'+name+'-'+profile+'.txt')
        closures[name]=sorted(set(re.findall(r'sluice/[\w/.-]+\.hpp',out)))
        run(args+['-fsyntax-only',str(source)],'compile-'+name+'-'+profile+'.log')
    (ev/('public-closure-'+profile+'.json')).write_text(json.dumps(closures,indent=2)+'\n')
    probe=base/'linked-host.cpp'
    probe.write_text('#include <sluice/async/stackful_io_host.hpp>\n#include <sluice/async/threadpool_backend.hpp>\nint main() { sluice::async::AsyncIoContext ctx(std::make_unique<sluice::async::ThreadPoolBackend>()); auto host=sluice::async::StackfulIoHost::create(ctx, {}); return host ? 0 : 1; }\n')
    binary=base/('linked-host-'+profile)
    args=['g++','-std=c++20','-g','-I'+str(prefix/'include')]
    if profile=='y': args+=['-DSLUICE_HAS_LIBURING']
    args += [str(probe),str(prefix/'lib/libsluice_async.a'),str(prefix/'lib/libsluice_core.a'),'-pthread','-Wl,-Map='+str(ev/('linked-host-'+profile+'.map')),'-o',str(binary)]
    if profile=='y': args+=['-luring']
    run(args,'link-host-'+profile+'.log'); run([str(binary)],'run-host-'+profile+'.log')
    run(['nm','-C',str(binary)],'symbols-host-'+profile+'.txt')
    summary[profile]={'headers':len(headers),'library_objects':sum('/sluice_core/' in x or '/sluice_async/' in x for x in objects),'async_archive_members':len((ev/('archive-async-'+profile+'.txt')).read_text().splitlines()),'closure_counts':{k:len(v) for k,v in closures.items()}}
(ev/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
