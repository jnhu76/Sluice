import pathlib,json,re,hashlib,shutil,subprocess
b=pathlib.Path('/home/jnhu/f3-postmerge-package-20261011'); e=b/'evidence'
d=pathlib.Path('/home/jnhu/f3-runtime-retirement-audit/docs/evidence/f3-runtime-postmerge-20261011'); d.mkdir(parents=True,exist_ok=True)
closures=json.loads((e/'public-closure-n.json').read_text())
canon=set(closures['request']+closures['context']) | {'sluice/async/request_scope.hpp','sluice/async/threadpool_backend.hpp','sluice/async/uring_backend.hpp','sluice/async/cancel.hpp','sluice/async/thread_annotations.hpp','sluice/async/detail/context_identity.hpp','sluice/async/detail/reference_ready_sink.hpp','sluice/async/detail/submit_transaction.hpp'}
host=set(closures['host'])-canon
headers=[]
for h in (e/'installed-headers-n.txt').read_text().splitlines():
    if h.endswith(('mutex_test_seam.hpp','queue_test_seam.hpp')): c='TEST_ONLY'
    elif h in canon: c='REQUIRED_INTERNAL_SUBSTRATE' if '/detail/' in h or h.endswith(('completion.hpp','cancel.hpp','thread_annotations.hpp')) else 'REQUIRED_CANONICAL'
    elif h in host: c='OPTIONAL_HOST_INTERNAL'
    elif h in ('sluice/file.hpp','sluice/blocking/file.hpp','sluice/detail/file_semantics.hpp','sluice/detail/posix_retry.hpp'): c='REQUIRED_CANONICAL'
    else: c='COMPATIBILITY_PENDING_EXTERNAL_GATE'
    headers.append({'path':h,'classification':c,'physical_retirement_authorized':False})
(d/'installed-header-classification.json').write_text(json.dumps(headers,indent=2)+'\n')
for p in ('n','y'):
    for stem in ('resolved','public-closure','installed-headers','archive-core','archive-async','objects'):
        suffix='.json' if stem in ('resolved','public-closure') else '.txt'
        shutil.copy2(e/(stem+'-'+p+suffix),d/(stem+'-'+p+suffix))
    resolved=json.loads((e/('resolved-'+p+'.json')).read_text())
    for name,row in resolved.items():
        actual=[x for x in row['objects'] if (b/'profiles'/p/x).is_file()]
        assert len(actual)==len(row['objects']),(name,actual)
shutil.copy2(e/'summary.json',d/'summary.json')
pattern=re.compile(r'ApplicationRuntime|RuntimeBuilder|RuntimeTaskContext|sluice::async::Scheduler|sluice::async::Group|sluice::async::Future|WaitPolicy|TaskResultSlot|sluice::async::Fiber|fiber_ctx|StackfulIoHost|Completion')
symbols={}
for p in ('n','y'):
    symbols[p]={}
    for name in ('host','copy','tail','hash','grep'):
        lines=(e/('symbols-'+name+'-'+p+'.txt')).read_text().splitlines()
        hits=[x for x in lines if pattern.search(x)]
        symbols[p][name]=hits
(d/'linked-runtime-family-symbols.json').write_text(json.dumps(symbols,indent=2)+'\n')
inventory={str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(e.iterdir()) if p.is_file()}
(d/'raw-evidence-sha256.json').write_text(json.dumps(inventory,indent=2)+'\n')
subprocess.run(['tar','-czf',str(d/'raw-build-package-symbols.tar.gz'),'-C',str(b),'evidence','capture.py','inventory.lua','classify.py','linked-host.cpp'],check=True)
print(d)
