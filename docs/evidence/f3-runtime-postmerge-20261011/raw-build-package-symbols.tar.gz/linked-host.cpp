#include <sluice/async/stackful_io_host.hpp>
#include <sluice/async/threadpool_backend.hpp>
int main() { sluice::async::AsyncIoContext ctx(std::make_unique<sluice::async::ThreadPoolBackend>()); auto host=sluice::async::StackfulIoHost::create(ctx, {}); return host ? 0 : 1; }
