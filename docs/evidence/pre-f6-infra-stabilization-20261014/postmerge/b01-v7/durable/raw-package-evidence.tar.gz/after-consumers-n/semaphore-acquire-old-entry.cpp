
#include <sluice/async/async_io_context.hpp>
#include <sluice/async/scheduler.hpp>
#include <sluice/async/semaphore.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <memory>
int main() {
    using namespace sluice::async;
    AsyncIoContext io(std::make_unique<ThreadPoolBackend>());
    Scheduler scheduler(io);
    Semaphore semaphore(scheduler, 1, 1);
    if (!semaphore.try_acquire()) return 2;
    return semaphore.release() ? 0 : 3;
}
