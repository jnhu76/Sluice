
#include <sluice/async/async_io_context.hpp>
#include <sluice/async/async_queue.hpp>
#include <sluice/async/scheduler.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <memory>
int main() {
    using namespace sluice::async;
    AsyncIoContext io(std::make_unique<ThreadPoolBackend>());
    Scheduler scheduler(io);
    AsyncQueue<int> queue(scheduler, 4);
    auto result = queue.try_push(7);
    return result.status() == QueuePushStatus::committed ? 0 : 2;
}
