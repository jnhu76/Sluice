#include <sluice/async/lock_guard.hpp>
int main() {}
