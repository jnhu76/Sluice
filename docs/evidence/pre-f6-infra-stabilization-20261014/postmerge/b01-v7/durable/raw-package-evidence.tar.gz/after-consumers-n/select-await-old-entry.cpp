
#include <sluice/async/event.hpp>
#include <sluice/async/select.hpp>
int main() {
    using namespace sluice::async;
    Scheduler& scheduler = *reinterpret_cast<Scheduler*>(0);
    Event event(scheduler);
    SelectResult result = select(scheduler, EventSelectCase{event});
    return result.index() == 0 ? 0 : 2;
}
