
#include <sluice/async/async_mutex.hpp>
int main() {
    sluice::async::Scheduler& scheduler =
        *reinterpret_cast<sluice::async::Scheduler*>(0);
    sluice::async::AsyncMutex mutex(scheduler);
    sluice::async::WaitNode node;
    mutex.lock(node);
    mutex.unlock();
    return 0;
}
