#include <sluice/async/detail/select_registration.hpp>
int main() {}
