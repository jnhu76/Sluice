
#include <sluice/async/async_rwlock.hpp>
int main() {
    sluice::async::Scheduler& scheduler =
        *reinterpret_cast<sluice::async::Scheduler*>(0);
    sluice::async::AsyncRwLock lock(scheduler);
    sluice::async::WaitNode node;
    lock.write_lock(node);
    lock.unlock_write();
    return 0;
}
