
#include <sluice/async/wait_policy.hpp>
using OldPolicy = sluice::async::WaitPolicy& (*)() noexcept;
int main() { OldPolicy p = &sluice::async::default_wait_policy;
    return p == nullptr; }
