
#include <sluice/async/event.hpp>
int main() {
    sluice::async::Scheduler& scheduler =
        *reinterpret_cast<sluice::async::Scheduler*>(0);
    sluice::async::Event event(scheduler);
    event.set();
    event.reset();
    return 0;
}
