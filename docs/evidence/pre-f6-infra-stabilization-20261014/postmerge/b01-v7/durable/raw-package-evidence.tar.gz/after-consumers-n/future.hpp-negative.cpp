#include <sluice/async/future.hpp>
int main() {}
