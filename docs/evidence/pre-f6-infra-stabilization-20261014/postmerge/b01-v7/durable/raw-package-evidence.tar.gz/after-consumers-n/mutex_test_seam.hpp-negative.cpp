#include <sluice/async/detail/mutex_test_seam.hpp>
int main() {}
