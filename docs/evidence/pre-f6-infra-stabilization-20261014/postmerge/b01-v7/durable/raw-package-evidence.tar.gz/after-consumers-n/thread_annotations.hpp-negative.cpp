#include <sluice/async/thread_annotations.hpp>
int main() {}
