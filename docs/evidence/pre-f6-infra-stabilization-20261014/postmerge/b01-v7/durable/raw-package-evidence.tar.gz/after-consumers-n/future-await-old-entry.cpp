
#include <sluice/async/future.hpp>
int main() {
    using namespace sluice::async;
    Future<void> future;
    future.complete_with(sluice::Result<void>{});
    return future.await() ? 0 : 1;
}
