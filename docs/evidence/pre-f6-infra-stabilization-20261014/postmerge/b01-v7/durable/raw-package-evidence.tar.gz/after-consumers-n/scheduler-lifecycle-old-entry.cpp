
#include <sluice/async/async_io_context.hpp>
#include <sluice/async/fiber.hpp>
#include <sluice/async/scheduler.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <array>
#include <memory>
int main() {
    using namespace sluice::async;
    AsyncIoContext io(std::make_unique<ThreadPoolBackend>());
    Scheduler scheduler(io);
    std::array<std::byte, 65536> stack{};
    Fiber fiber([](Fiber&) {});
    if (!scheduler.init_fiber(fiber, stack.data(), stack.size())) return 2;
    scheduler.spawn(fiber);
    scheduler.run(1);
    return fiber.state() != FiberState::done;
}
