#include <sluice/async/async_queue.hpp>
int main() {}
