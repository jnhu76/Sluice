
#include <sluice/async/async_io_context.hpp>
#include <sluice/async/condition.hpp>
#include <sluice/async/scheduler.hpp>
#include <sluice/async/threadpool_backend.hpp>
#include <memory>
int main() {
    using namespace sluice::async;
    AsyncIoContext io(std::make_unique<ThreadPoolBackend>());
    Scheduler scheduler(io);
    AsyncMutex mutex(scheduler);
    AsyncCondition condition(mutex);
    condition.notify_one();
    condition.notify_all();
    return 0;
}
