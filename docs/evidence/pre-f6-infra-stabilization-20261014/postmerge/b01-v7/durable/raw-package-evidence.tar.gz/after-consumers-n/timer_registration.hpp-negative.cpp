#include <sluice/async/timer_registration.hpp>
int main() {}
