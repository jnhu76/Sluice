#include <sluice/async/wait_node.hpp>
int main() {}
